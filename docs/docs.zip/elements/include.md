---
layout: index
title: include element
---

    <include ref="filename"/>

Loads the specified library.
