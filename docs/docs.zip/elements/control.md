---
layout: index
title: control element
---

    <control>nameattributes</control>

This defines the controls within a [tab element](tab.html).

Attributes:

attribute  
[string](../types/string.html) specifying the attribute name that this control applies to

caption  
[string](../types/string.html) specifying the label for the control

controltype  
[string](../types/string.html) specifying the control type

See [Editor User Interface Elements](../editor_user_interface_elements.html)
