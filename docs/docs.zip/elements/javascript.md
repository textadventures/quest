---
layout: index
title: javascript element
---

    <javascript src="filename"/>

Adds the specified Javascript file to the player interface.
