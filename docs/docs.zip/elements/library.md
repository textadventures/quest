---
layout: index
title: library element
---

    <library>all library content</library>

The top-level element of any library must be a \<library\> element as shown above. All other XML elements in the file must appear within this tag.
