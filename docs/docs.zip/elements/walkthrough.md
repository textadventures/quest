---
layout: index
title: walkthrough element
---

    <walkthrough name="name" > <steps>steps</steps> </walkthrough>

Defines a walkthrough with a list of steps. Each step should be on its own line.

Walkthrough elements can be nested within each other to create a hierarchy.

See [Walkthroughs](../guides/walkthroughs.html).
