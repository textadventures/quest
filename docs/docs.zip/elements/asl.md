---
layout: index
title: asl element
---

    <asl version="500">all game content</asl>

To load any game, the top-level element must be an \<asl\> element as shown above. All other XML elements in the file must appear within this tag.
