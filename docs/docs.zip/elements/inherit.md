---
layout: index
title: inherit element
---

    <inherit name="name"/>

Within an object, type, command or exit definition, inherits properties from the specified type.

See [Types](../types.html).
