---
layout: index
title: tab element
---

    <tab>attributes</tab>

This defines a tab within an [editor element](editor.html).

It should have nested [control](control.html) elements.

Attributes:

caption  
[string](../types/string.html) specifying the caption for the tab


