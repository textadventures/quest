---
layout: index
title: dark
---

"dark" is a [boolean](../types/boolean.html) attribute. If set to true, the room is dark.
