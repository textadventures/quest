---
layout: index
title: switchedoffdesc
---

"switchedoffdesc" is a [string](../types/string.html) attribute, specifying additional text to print after the object description when the object is switched off.

See also [switchedondesc](switchedondesc.html).
