---
layout: index
title: isopen
---

"isopen" is a [boolean](../types/boolean.html) attribute - a value of "true" means the object is open, and a value of "false" means the object is closed.
