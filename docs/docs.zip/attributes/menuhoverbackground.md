---
layout: index
title: menuhoverbackground
---

"menuhoverbackground" is a [string](../types/string.html) attribute which should be set to a valid HTML colour name. It specifies the background colour to use when hovering over a menu item.
