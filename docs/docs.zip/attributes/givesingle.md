---
layout: index
title: givesingle
---

"givesingle" is a [script](../types/script.html) attribute. It is run when the player types "give (object)" on its own.
