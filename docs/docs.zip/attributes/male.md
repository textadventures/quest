---
layout: index
title: male
---

The "male" type is defined in CoreTypes.aslx. It sets the [gender](gender.html) and [article](article.html) as appropriate for a male character, and sets the [displayverbs](displayverbs.html) to "Look at" and "Speak to".
