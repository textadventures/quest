---
layout: index
title: pov_gender
---

"pov\_gender" is a [string](../types/string.html) attribute. When an object becomes the player object, the [gender](gender.html) attribute will be set to this value.
