---
layout: index
title: surface
---

The "surface" type is defined in CoreTypes.aslx. It implements a surface by setting up the object as a transparent, open container which cannot be closed.
