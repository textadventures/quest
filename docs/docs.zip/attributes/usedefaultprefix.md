---
layout: index
title: usedefaultprefix
---

"usedefaultprefix" is a [boolean](../types/boolean.html) attribute. If set to true, the object's [prefix](prefix.html) is ignored if set, and a default prefix is used instead - for English games, "a" or "an" is used.
