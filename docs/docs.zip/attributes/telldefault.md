---
layout: index
title: telldefault
---

"telldefault" is a [script](../types/script.html) which is the default script to run when an object is told about a topic. If none of the topics in the [tell](tell.html) scriptdictionary match the player's input, the telldefault script is run.
