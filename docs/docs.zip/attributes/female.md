---
layout: index
title: female
---

The "female" type is defined in CoreTypes.aslx. It sets the [gender](gender.html) and [article](article.html) as appropriate for a female character, and sets the [displayverbs](displayverbs.html) to "Look at" and "Speak to".
