---
layout: index
title: parserignoreprefixes
---

"parserignoreprefixes" is a [stringlist](../types/stringlist.html) attribute specifying a list of words which the parser should ignore if they appear at the beginning of object names - for example "the", "a", "an".
