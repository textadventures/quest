---
layout: index
title: transparent
---

"transparent" is a [boolean](../types/boolean.html) attribute. If "true", it means that objects inside the container can be seen (but not reached) even when the container is closed.
