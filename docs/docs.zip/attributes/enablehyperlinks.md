---
layout: index
title: enablehyperlinks
---

"enablehyperlinks" is a [boolean](../types/boolean.html) attribute specifying whether hyperlinks are enabled in the game.
