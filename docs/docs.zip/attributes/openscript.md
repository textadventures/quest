---
layout: index
title: openscript
---

"openscript" is a [script](../types/script.html) attribute. If specified, when the object is opened, the script will run. If not specified, the object will be opened automatically.

See also [open](open.html).
