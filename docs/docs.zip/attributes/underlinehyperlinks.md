---
layout: index
title: underlinehyperlinks
---

"underlinehyperlinks" is a [boolean](../types/boolean.html) attribute. If set to true, hyperlinks will be underlined.
