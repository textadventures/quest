---
layout: index
title: onswitchon
---

"onswitchon" specifies the [script](../types/script.html) to run after the object is switched on.
