---
layout: index
title: onswitchoff
---

"onswitchoff" specifies the [script](../types/script.html) to run after the object is switched off.
