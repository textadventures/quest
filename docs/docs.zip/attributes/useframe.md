---
layout: index
title: useframe
---

"useframe" is a [boolean](../types/boolean.html) attribute specifying whether a static picture frame should be displayed above the game text.

No longer used as of Quest 5.1 - all games can use the static picture frame, without having to turn this attribute on.
