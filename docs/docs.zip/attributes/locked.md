---
layout: index
title: locked
---

"locked" is a [boolean](../types/boolean.html) attribute, used on a container to specify that it is locked.
