---
layout: index
title: menufontsize
---

"menufontsize" is an [int](../types/int.html) attribute. It specifies the font size for menus.
