---
layout: index
title: backgroundopacity
---

"backgroundopacity" is a [double](../types/double.html) attribute. It specifies the opacity of the background, from 0.0 to 1.0.
