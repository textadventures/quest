---
layout: index
title: onopen
---

"onopen" specifies the [script](../types/script.html) to run after the object is opened.
