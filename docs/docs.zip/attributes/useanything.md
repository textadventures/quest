---
layout: index
title: useanything
---

"useanything" is a [script](../types/script.html) attribute. It is the fallback for [useon](useon.html) - if the object being used does not appear in the "useon" list, this script if specified will run instead. The script can read the "object" variable to see what object is being used.
