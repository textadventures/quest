---
layout: index
title: containerfullmessage
---

"containerfullmessage" is a [string](../types/string.html) attribute, used only when the object is a limited container ([container\_limited](container_limited.html) type). If specified, it is used instead of the ContainerFull template when the player tries to add an object inside the container when it is full.
