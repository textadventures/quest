---
layout: index
title: descprefix
---

"descprefix" is a [string](../types/string.html) attribute specifying the text to print before the room name in a room description. The default comes from the YouAreIn template ("You are in").
