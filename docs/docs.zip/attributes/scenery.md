---
layout: index
title: scenery
---

"scenery" is a [boolean](../types/boolean.html) attribute. If set to true, the object is not automatically listed in room descriptions or in the "Places and Objects" list. It is still within [ScopeVisible](../functions/corelibrary/scopevisible.html) though, so the player can look at and interact with the object.
