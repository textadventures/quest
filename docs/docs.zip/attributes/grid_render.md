---
layout: index
title: grid_render
---

"grid\_render" is a [boolean](../types/boolean.html) attribute. It is used by the Core library so it can keep track of which rooms have been drawn on the grid, so it should not be set directly.
