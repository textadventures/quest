---
layout: index
title: objectslistprefix
---

"objectslistprefix" is a [string](../types/string.html) attribute, used when printing the room description, before the list of objects in the room. If not specified it defaults to the SeeListHeader template ("You can see").
