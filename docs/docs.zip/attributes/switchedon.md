---
layout: index
title: switchedon
---

"switchedon" is a [boolean](../types/boolean.html) attribute specifying whether the object is switched on.
