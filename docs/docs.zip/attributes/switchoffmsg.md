---
layout: index
title: switchoffmsg
---

"switchoffmsg" is a [string](../types/string.html) attribute, specifying text to print when the user switches off the object. If not specified, the SwitchedOff template is printed.

See also [switchonmsg](switchonmsg.html).
