---
layout: index
title: givetoanything
---

"givetoanything" is a [script](../types/script.html) attribute. It is the fallback for [giveto](giveto.html) - if the object being used does not appear in the "giveto" list, this script if specified will run instead. The script can read the "object" variable to see what object is being used.
