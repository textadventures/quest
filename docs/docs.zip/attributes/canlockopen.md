---
layout: index
title: canlockopen
---

"canlockopen" is a [boolean](../types/boolean.html) attribute, specifying whether an object can be locked while it is open (thereby locking it open, so the object would have to be unlocked before it could be closed).
