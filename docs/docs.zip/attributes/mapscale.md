---
layout: index
title: mapscale
---

"mapscale" is an [int](../types/int.html) attribute. It specifies the length in pixels of one grid unit.
