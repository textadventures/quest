---
layout: index
title: grid_parent_offset_auto
---

"grid\_parent\_offset\_auto" is a [boolean](../types/boolean.html) attribute. It specifies whether to display this room in the default position on the map. If set to false, use [grid\_parent\_offset\_x](grid_parent_offset_x.html) and [grid\_parent\_offset\_y](grid_parent_offset_y.html) to specify where this room should appear in relation to its parent room.
