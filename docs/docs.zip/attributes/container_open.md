---
layout: index
title: container_open
---

The "container\_open" type is defined in CoreTypes.aslx. It implements an open container.

By inheriting the "container\_open" type in an object, it becomes by default [openable](open.html) and [closable](close.html). "Open" and "Close" are added as [displayverbs](displayverbs.html).
