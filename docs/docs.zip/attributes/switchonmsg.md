---
layout: index
title: switchonmsg
---

"switchonmsg" is a [string](../types/string.html) attribute, specifying text to print when the user switches on the object. If not specified, the SwitchedOn template is printed.

See also [switchoffmsg](switchoffmsg.html).
