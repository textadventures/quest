---
layout: index
title: tell
---

"tell" is a [scriptdictionary](../types/scriptdictionary.html). Keys are topics, and values are the scripts to run when the object is told about that topic.

See also [Tutorial: Ask and Tell](../tutorial/more_things_to_do_with_objects.html#Ask_and_Tell), [telldefault](telldefault.html), [ask](../ask_attribute.html).
