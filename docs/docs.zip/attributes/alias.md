---
layout: index
title: alias
---

The "alias" attribute is a [string](../types/string.html), and is the displayed name of the object - the one that the player sees. If the object has no alias, the displayed name will be the same as the "name" attribute for the object element.
