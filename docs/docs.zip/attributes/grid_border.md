---
layout: index
title: grid_border
---

"grid\_border" is a [string](../types/string.html) attribute. It specifies the HTML colour name to use for the border colour for this room on the map.
