---
layout: index
title: statusattributes
---

"statusattributes" is a [stringlist](../types/stringlist.html) attribute, only applicable for the [game](../elements/game.html) and [player](../player.html) objects. See [Status Attributes](../status_attributes.html).
