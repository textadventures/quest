---
layout: index
title: exitslistprefix
---

"exitslistprefix" is a [string](../types/string.html) attribute, specifying text to print in the room description before the list of exits. If not specified, it defaults to the value of the GoListHeader template ("You can go").
