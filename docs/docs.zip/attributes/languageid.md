---
layout: index
title: languageid
---

"languageid" is a [string](../types/string.html) attribute. It is metadata specifying the game's language code - this will be used by the textadventures.co.uk site to filter games by language.
