---
layout: index
title: selfuseanything
---

"selfuseanything" is a [script](../types/script.html) attribute. It is the fallback for [selfuseon](selfuseon.html) - if the object being used does not appear in the "selfuse" list, this script if specified will run instead. The script can read the "object" variable to see what object is being used.
