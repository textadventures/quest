---
layout: index
title: showpanes
---

"showpanes" is a [boolean](../types/boolean.html) attribute specifying whether the panes on the right of the screen ("Inventory", "Places and Objects" and "Compass") should be displayed.
