---
layout: index
title: setbackgroundopacity
---

"setbackgroundopacity" is a [boolean](../types/boolean.html) attribute. If set to true, the opacity specified in [backgroundopacity](backgroundopacity.html) will be applied.
