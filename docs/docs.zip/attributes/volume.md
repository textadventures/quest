---
layout: index
title: volume
---

"volume" is an [int](../types/int.html) attribute. It specifies the volume of the object. This can then be used with [container\_limited](container_limited.html) to limit the size of objects which can be put inside a container.
