---
layout: index
title: switchedondesc
---

"switchedondesc" is a [string](../types/string.html) attribute, specifying additional text to print after the object description when the object is switched on.

See also [switchedoffdesc](switchedoffdesc.html).
