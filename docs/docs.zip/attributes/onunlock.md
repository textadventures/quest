---
layout: index
title: onunlock
---

"onunlock" specifies the [script](../types/script.html) to run after the object is unlocked.
