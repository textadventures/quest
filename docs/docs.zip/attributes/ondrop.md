---
layout: index
title: ondrop
---

"ondrop" specifies the [script](../types/script.html) to run after the object is dropped.
