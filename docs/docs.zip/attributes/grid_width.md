---
layout: index
title: grid_width
---

"grid\_width" is an [int](../types/int.html) attribute. It specifies the width (in grid units) of this room on the map.
