---
layout: index
title: defaultwebfont
---

"defaultwebfont" is a [string](../types/string.html) attribute which should be set to a valid web font name. It specifies the default web font for the game. This is used in preference to the [defaultfont](defaultfont.html) if web fonts are available.
