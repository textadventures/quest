---
layout: index
title: ask
---

"ask" is a [scriptdictionary](../types/scriptdictionary.html). Keys are topics, and values are the scripts to run when the object is asked about that topic.

See also [Tutorial: Ask and Tell](../tutorial/more_things_to_do_with_objects.html#Ask_and_Tell), [askdefault](askdefault.html), [tell](tell.html).
