---
layout: index
title: displayverbs
---

"displayverbs" is a [stringlist](../types/stringlist.html) attribute, defining the verbs that appear when the object's hyperlink is clicked. The verbs also appear as buttons when the object is selected in the "Places and Objects" pane.

See also [inventoryverbs](inventoryverbs.html).
