---
layout: index
title: unlockmessage
---

"unlockmessage" is a [string](../types/string.html) attribute, used to specify the text to print when the player unlocks the container. If not specified, the UnlockMessage template is the default.

See also [lockmessage](lockmessage.html).
