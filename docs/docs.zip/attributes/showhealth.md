---
layout: index
title: showhealth
---

"showhealth" is a [boolean](../types/boolean.html) attribute. If set to true, a health status variable will be created for each player (POV) object.
