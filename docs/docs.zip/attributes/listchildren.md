---
layout: index
title: listchildren
---

"listchildren" is a [boolean](../types/boolean.html) attribute, specifying whether to list child objects when this object is looked at or opened.

See also [listchildrenprefix](listchildrenprefix.html).
