---
layout: index
title: onlock
---

"onlock" specifies the [script](../types/script.html) to run after the object is locked.
