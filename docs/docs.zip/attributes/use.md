---
layout: index
title: use
---

"use" is a [script](../types/script.html) attribute, specifying script to run when the player types "use (object)"
