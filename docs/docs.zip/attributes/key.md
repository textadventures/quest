---
layout: index
title: key
---

"key" is an [object](../types/object.html) attribute, used for locked containers to specify which object is the "key" object that unlocks this object.
