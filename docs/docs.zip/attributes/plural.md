---
layout: index
title: plural
---

The "plural" type is defined in CoreTypes.aslx. It sets the [gender](gender.html) and [article](article.html) as appropriate for plural inanimate objects.
