---
layout: index
title: visited
---

"visited" is a [boolean](../types/boolean.html) attribute. Quest's core library sets the "visited" attribute of an object to true when the player enters that object (room). There should usually be no need to set the visited attribute yourself, but you can read its value to see if the player has been to a room in your game.
