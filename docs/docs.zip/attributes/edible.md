---
layout: index
title: edible
---

The "edible" type implements an "eat" verb for an object. If [showhealth](showhealth.html) is enabled, when the object is eaten, the player's health can be increased or decreased by the amount specified in the "eathealth" attribute (an [int](../types/int.html))
