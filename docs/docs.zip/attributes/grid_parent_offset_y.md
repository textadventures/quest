---
layout: index
title: grid_parent_offset_y
---

"grid\_parent\_offset\_y" is an [int](../types/int.html) attribute. It specifies the offset of this room from its parent on the Y axis.
