---
layout: index
title: contentsprefix
---

"contentsprefix" is a [string](../types/string.html) attribute specifying the text to print before listing the object contents in a room description. The default comes from the ContainerContentsPrefix ("containing") or SurfaceContentsPrefix ("on which there is") templates.
