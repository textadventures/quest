---
layout: index
title: article
---

"article" is a [string](../types/string.html) attribute. In English games it is usually "it" for inanimate objects, or "him" or "her" for characters.

It is usually used when constructing default responses, for example "You can't take **it**", "You can't take **him**", etc.

See also [gender](gender.html).
