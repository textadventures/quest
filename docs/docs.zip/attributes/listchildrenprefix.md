---
layout: index
title: listchildrenprefix
---

"listchildrenprefix" is a [string](../types/string.html) attribute, used when listing children of an object. It only applies when [listchildren](listchildren.html) is set. The default is the ObjectContains template.
