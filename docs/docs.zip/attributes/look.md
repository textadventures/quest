---
layout: index
title: look
---

"look" is an attribute that can be either [string](../types/string.html) or [script](../types/script.html). It specifies what happens when the player looks at the object.

-   If not specified, the DefaultObjectDescription template is printed ("Nothing out of the ordinary").
-   If [string](../types/string.html), that is printed.
-   If [script](../types/script.html), that is run.

