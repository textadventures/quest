---
layout: index
title: namedmale
---

The "namedmale" type is equivalent to [male](male.html), but also turns off [usedefaultprefix](usedefaultprefix.html) so no prefix is displayed. Use this for named male characters, e.g. "Bob".
