---
layout: index
title: mapsize
---

"mapsize" is an [int](../types/int.html) attribute. It specifies the height in pixels of the map display area.
