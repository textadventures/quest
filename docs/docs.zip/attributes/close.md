---
layout: index
title: close
---

"close" is a [boolean](../types/boolean.html) attribute specifying whether the object can be closed.

See also [closescript](closescript.html), [open](open.html).
