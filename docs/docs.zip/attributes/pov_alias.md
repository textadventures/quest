---
layout: index
title: pov_alias
---

"pov\_alias" is a [string](../types/string.html) attribute. When an object becomes the player object, the [alias](alias.html) will be set to this value.
