---
layout: index
title: defaultforeground
---

"defaultforeground" is a [string](../types/string.html) attribute which should be set to a valid HTML colour name. It specifies the default foreground colour for the game.
