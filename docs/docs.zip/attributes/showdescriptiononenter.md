---
layout: index
title: showdescriptiononenter
---

"showdescriptiononenter" is a [boolean](../types/boolean.html) attribute specifying whether the room description is automatically displayed when the player enters a room.
