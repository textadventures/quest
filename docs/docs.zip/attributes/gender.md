---
layout: index
title: gender
---

"gender" is a [string](../types/string.html) attribute. In English games it is usually "it" for inanimate objects, or "he" or "she" for characters.

It is usually used when constructing default responses, for example "**He** says nothing", "**It** is already closed", etc.

See also [article](article.html).
