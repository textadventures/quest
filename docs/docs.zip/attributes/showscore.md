---
layout: index
title: showscore
---

"showscore" is a [boolean](../types/boolean.html) attribute. If set to true, a score status variable will be created on the game object.
