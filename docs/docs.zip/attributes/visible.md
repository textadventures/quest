---
layout: index
title: visible
---

"visible" is a [boolean](../types/boolean.html) attribute. If set to false, the object is not displayed - the effect is the same as if the object's parent is set to null.
