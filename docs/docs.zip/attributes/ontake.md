---
layout: index
title: ontake
---

"ontake" specifies the [script](../types/script.html) to run after the object is taken.
