---
layout: index
title: onexit
---

"onexit" is a [script](../types/script.html) attribute. It is run every time that a player leaves an object (room).

See also [enter](enter.html).
