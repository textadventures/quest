---
layout: index
title: inventoryverbs
---

"inventoryverbs" is a [stringlist](../types/stringlist.html) attribute, defining the verbs that appear when the object's hyperlink is clicked (when the object is in the inventory, so after the user types "inventory"). The verbs also appear as buttons when the object is selected in the "Inventory" pane.

See also [displayverbs](displayverbs.html).
