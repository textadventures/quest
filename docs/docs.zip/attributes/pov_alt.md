---
layout: index
title: pov_alt
---

"pov\_alt" is a [stringlist](../types/stringlist.html) attribute. When an object becomes the player object, the [alt](alt.html) attribute will be set to this value.
