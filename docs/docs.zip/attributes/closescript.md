---
layout: index
title: closescript
---

"closescript" is a [script](../types/script.html) attribute. If specified, when the object is closed, the script will run. If not specified, the object will be closed automatically.

See also [close](close.html).
