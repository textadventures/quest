---
layout: index
title: pov_look
---

"pov\_look" can be a [string](../types/string.html) or [script](../types/script.html). When an object becomes the player object, the [look](look.html) attribute will be set to this value.
