---
layout: index
title: namedfemale
---

The "namedfemale" type is equivalent to [female](female.html), but also turns off [usedefaultprefix](usedefaultprefix.html) so no prefix is displayed. Use this for named female characters, e.g. "Sue".
