---
layout: index
title: grid_borderwidth
---

"grid\_borderwidth" is an [int](../types/int.html) attribute. It specifies the width of this room's border on the map, in pixels.
