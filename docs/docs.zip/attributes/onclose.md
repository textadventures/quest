---
layout: index
title: onclose
---

"onclose" specifies the [script](../types/script.html) to run after the object is closed.
