---
layout: index
title: nokeymessage
---

"nokeymessage" is a [string](../types/string.html) attribute, used with locked containers. It is printed when the player attempts to lock or unlock the object, but don't have the object specified by the [key](key.html) attribute in their inventory. If not specified, the NoKey template is used.
