---
layout: index
title: editor_object
---

Dummy type used by the Editor so it can distinguish between objects that are intended to be rooms, and objects that are intended to be objects inside rooms.

This dummy type, like [editor\_room](editor_room.html), is removed when the game is published to a .quest file.
