---
layout: index
title: gridmap
---

"gridmap" is a [boolean](../types/boolean.html) attribute. If set to "true", the automatically generated grid-based map is displayed.
