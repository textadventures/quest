---
layout: index
title: suffix
---

"suffix" is a [string](../types/string.html) attribute, specifying text which appears after the object name when it is printed in a room description.

See also [prefix](prefix.html).
