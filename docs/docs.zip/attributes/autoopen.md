---
layout: index
title: autoopen
---

"autoopen" is a [boolean](../types/boolean.html) attribute, specifying whether to automatically open an object when it is unlocked.
