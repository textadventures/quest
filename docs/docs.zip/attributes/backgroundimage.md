---
layout: index
title: backgroundimage
---

"backgroundimage" is a [string](../types/string.html) attribute. It specifies the image filename to use as a background.
