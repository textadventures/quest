---
layout: index
title: displayroomdescriptiononstart
---

"displayroomdescriptiononstart" is a [boolean](../types/boolean.html) attribute. If set to "true", the room description for the player start room is displayed when the game begins.
