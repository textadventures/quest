---
layout: index
title: maxobjects
---

"maxobjects" is an [int](../types/int.html) attribute, used when the [container\_limited](container_limited.html) type is in use for a limited container. It specifies the maximum number of objects that can be placed inside the container.
