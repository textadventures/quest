---
layout: index
title: appendobjectdescription
---

"appendobjectdescription" is a [boolean](../types/boolean.html) attribute. If set to "true", when room descriptions are printed, the [description](description.html) tag of the objects inside the room is appended.
