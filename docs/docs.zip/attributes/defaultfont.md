---
layout: index
title: defaultfont
---

"defaultfont" is a [string](../types/string.html) attribute which should be set to a valid font name. It specifies the default font for the game. If web fonts are available, the [defaultwebfont](defaultwebfont.html) will be used instead.
