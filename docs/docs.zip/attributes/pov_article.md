---
layout: index
title: pov_article
---

"pov\_article" is a [string](../types/string.html) attribute. When an object becomes the player object, the [article](article.html) attribute will be set to this value.
