---
layout: index
title: takemsg
---

"takemsg" is a [string](../types/string.html) attribute, specifying the text to print when the user takes (or tries to take) the object. Only applicable if the [take](take.html) attribute is [boolean](../types/boolean.html).
