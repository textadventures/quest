---
layout: index
title: allobjects
---

"allobjects" is a [stringlist](../types/stringlist.html) attribute. It specifies which words the parser will understand as meaning "all" in commands such as "take all".
