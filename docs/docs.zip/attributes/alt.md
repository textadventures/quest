---
layout: index
title: alt
---

The "alt" attribute is a [stringlist](../types/stringlist.html) of alternative names that the player can use to refer to this object.
