---
layout: index
title: lockmessage
---

"lockmessage" is a [string](../types/string.html) attribute, used to specify the text to print when the player locks the container. If not specified, the LockMessage template is the default.

See also [unlockmessage](unlockmessage.html).
