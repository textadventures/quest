---
layout: index
title: darklevel
---

"darklevel" is a [boolean](../types/boolean.html) attribute used internally by the room darkness code. You should use [dark](dark.html) to set whether the room is dark.
