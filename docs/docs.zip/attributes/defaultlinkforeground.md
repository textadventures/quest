---
layout: index
title: defaultlinkforeground
---

"defaultlinkforeground" is a [string](../types/string.html) attribute which should be set to a valid HTML colour name. It specifies the default hyperlink foreground colour for the game.
