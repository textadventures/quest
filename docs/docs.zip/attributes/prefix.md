---
layout: index
title: prefix
---

"prefix" is a [string](../types/string.html) attribute, specifying text which appears before the object name when it is printed in a room description.

See also [suffix](suffix.html).
