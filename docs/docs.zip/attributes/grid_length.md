---
layout: index
title: grid_length
---

"grid\_length" is an [int](../types/int.html) attribute. It specifies the length (in grid units) of this room on the map.
