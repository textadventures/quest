---
layout: index
title: askdefault
---

"askdefault" is a [script](../types/script.html) which is the default script to run when an object is asked about a topic. If none of the topics in the [ask](../ask_attribute.html) scriptdictionary match the player's input, the askdefault script is run.
