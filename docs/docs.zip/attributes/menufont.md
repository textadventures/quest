---
layout: index
title: menufont
---

"menufont" is a [string](../types/string.html) attribute which should be set to a valid font name. It specifies the font for menus.
