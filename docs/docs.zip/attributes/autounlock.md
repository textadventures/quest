---
layout: index
title: autounlock
---

"autounlock" is a [boolean](../types/boolean.html) attribute, specifying whether to automatically unlock the object when the player tries to open it (but only if they have the key)
