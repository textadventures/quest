---
layout: index
title: open
---

"open" is a [boolean](../types/boolean.html) attribute specifying whether the object can be opened.

See also [openscript](openscript.html), [close](close.html).
