---
layout: index
title: grid_parent_offset_x
---

"grid\_parent\_offset\_x" is an [int](../types/int.html) attribute. It specifies the offset of this room from its parent on the X axis.
