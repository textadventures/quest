---
layout: index
title: enter
---

"enter" is a [script](../types/script.html) attribute. It is run every time that a player enters an object (room), *after* the room description is printed.

See also [beforefirstenter](beforefirstenter.html), [firstenter](firstenter.html), [onexit](onexit.html).
