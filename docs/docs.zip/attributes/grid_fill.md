---
layout: index
title: grid_fill
---

"grid\_fill" is a [string](../types/string.html) attribute. It specifies the HTML colour name to use for the fill colour for this room on the map.
