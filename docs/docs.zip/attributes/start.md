---
layout: index
title: start
---

"start" is a [script](../types/script.html) attribute specifying script to run when the game begins.
