---
layout: index
title: picture (attribute)
---

"picture" is a [string](../types/string.html) attribute specifying the filename of the picture to display in the static picture frame when the player enters this room.
