---
layout: index
title: dropmsg
---

"dropmsg" is a [string](../types/string.html) attribute, specifying the text to print when the user drops (or tries to drop) the object. Only applicable if the [drop](drop.html) attribute is [boolean](../types/boolean.html).
