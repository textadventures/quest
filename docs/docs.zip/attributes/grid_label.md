---
layout: index
title: grid_label
---

"grid\_label" is a [string](../types/string.html) attribute. It specifies the text to display in the centre of this room on the map.
