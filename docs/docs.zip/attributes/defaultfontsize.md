---
layout: index
title: defaultfontsize
---

"defaultfontsize" is an [int](../types/int.html) attribute. It specifies the default font size for the game.
